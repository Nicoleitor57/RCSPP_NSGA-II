/* Mutation routines */

# include <stdio.h>
# include <stdlib.h>
# include <math.h>
#include <stdbool.h>
#include <string.h>


# include "global.h"
# include "rand.h"

#define MAX_PATCH_LENGTH 4  // Cuántos arcos máximo se pueden usar para reemplazar 1
#define MAX_ATTEMPTS 10     // Intentos antes de abortar la mutación
#define MAX_NODES 10000
#define MAX_GENES 50000
#define MAX(a, b) ((a) > (b) ? (a) : (b))

/* Function to perform mutation in a population */
void mutation_pop (population *pop, Instance *inst)
{
    int i;
    for (i=0; i<popsize; i++)
    {
        mutation_ind(&(pop->ind[i]), inst);
    }
    return;
}

// Baraja un arreglo de enteros. Necesario para la búsqueda aleatoria.
void shuffle_array(int *array, int n) {
    if (n > 1) {
        for (int i = 0; i < n - 1; i++) {
          int j = i + rnd(0, n - 1 - i);
          int temp = array[j];
          array[j] = array[i];
          array[i] = temp;
        }
    }
}


void mutation_ind(individual *ind, Instance *inst) 
{
    if (randomperc() < pmut_bin) {
        //printf("\n--- INTENTANDO MUTAR INDIVIDUO ---\n"); // <-- AÑADIR
        bool mutado = diversified_mutation(ind, inst);
        if (mutado) {
            //printf("--- ¡MUTACIÓN REALIZADA CON ÉXITO! ---\n\n"); // <-- AÑADIR
        } else {
            //printf("--- LA MUTACIÓN FALLÓ (NO SE HICIERON CAMBIOS) ---\n\n"); // <-- AÑADIR
        }
    }
}

int find_arc_index(Instance *inst, int from, int to) {
    for (int i = 0; i < inst->out_degrees[from]; i++) {
        int arc_idx = inst->outgoing_arcs[from][i];
        if (inst->arcs[arc_idx].to.id == to) {
            return arc_idx;
        }
    }
    return -1; // No encontrado
}

// Búsqueda en Anchura Aleatorizada para encontrar un parche.bool randomized_bfs_patch(Instance *inst, int from_node, int to_node, int* patch_nodes, int* patch_len, int arc_to_ignore) {
bool randomized_bfs_patch(Instance *inst, int from_node, int to_node, int* patch_nodes, int* patch_len, int arc_to_ignore) {
    printf("    [BFS] Iniciando búsqueda de parche desde %d a %d. Ignorando arco #%d.\n", from_node, to_node, arc_to_ignore);

    int queue[NUM_TOTAL_DE_NODOS];
    int parent[NUM_TOTAL_DE_NODOS];
    bool visited[NUM_TOTAL_DE_NODOS];
    memset(visited, false, sizeof(bool) * NUM_TOTAL_DE_NODOS);

    int front = 0, back = 0;
    queue[back++] = from_node;
    visited[from_node] = true;
    parent[from_node] = -1;

    bool found = false;
    while (front < back) {
        int u = queue[front++];
        if (u == to_node) {
            found = true;
            break;
        }
        
        int neighbors_arcs[inst->out_degrees[u]];
        for(int i=0; i < inst->out_degrees[u]; ++i) {
            neighbors_arcs[i] = inst->outgoing_arcs[u][i];
        }
        shuffle_array(neighbors_arcs, inst->out_degrees[u]);

        for (int i = 0; i < inst->out_degrees[u]; i++) {
            int current_arc_idx = neighbors_arcs[i];
            
            if (current_arc_idx == arc_to_ignore) {
                printf("    [BFS] Ignorando arco prohibido #%d que va de %d a %d.\n", arc_to_ignore, inst->arcs[arc_to_ignore].from.id, inst->arcs[arc_to_ignore].to.id);
                continue;
            }

            int v = inst->arcs[current_arc_idx].to.id;
            if (!visited[v]) {
                visited[v] = true;
                parent[v] = u;
                queue[back++] = v;
            }
        }
    }

    if (!found) {
        printf("    [BFS] Falló. No se pudo encontrar una ruta alternativa.\n");
        return false;
    }

    int temp_path[NUM_TOTAL_DE_NODOS];
    int len = 0;
    int curr = to_node;
    while (curr != -1) { temp_path[len++] = curr; curr = parent[curr]; }
    
    for(int i = 0; i < len; i++) patch_nodes[i] = temp_path[len - 1 - i];
    *patch_len = len;

    printf("    [BFS] ¡Parche encontrado! Longitud del nuevo camino de nodos: %d.\n", *patch_len);
    return true;
}


// --- Operador de Mutación Principal con Prints ---
bool diversified_mutation(individual *ind, Instance *inst) {
    int route_len = 0;
    while (route_len < nbits[0] && ind->gene[0][route_len] != -1) route_len++;

    if (route_len < 3) return false;

    for (int attempt = 0; attempt < 10; attempt++) {
        printf("\n  [MUT] Intento #%d/%d para el individuo.\n", attempt + 1, 10);
        
        int i = rnd(1, route_len - 2);
        int arc_to_replace_idx = ind->gene[0][i];

        int from_node = inst->arcs[arc_to_replace_idx].from.id;
        int to_node = inst->arcs[arc_to_replace_idx].to.id;
        
        printf("  [MUT] Intentando reemplazar el arco #%d (que va de %d a %d) en la posición %d de la ruta.\n", arc_to_replace_idx, from_node, to_node, i);

        if (from_node == to_node) {
             printf("  [MUT] Error lógico: el arco conecta un nodo consigo mismo. Reintentando.\n");
             continue;
        }

        int patch_nodes[nbits[0]];
        int patch_len = 0;
        bool found = randomized_bfs_patch(inst, from_node, to_node, &patch_nodes[0], &patch_len, arc_to_replace_idx);

        if (!found) {
            printf("  [MUT] El BFS no encontró un desvío. Reintentando con otro arco.\n");
            continue;
        }
        
        if (patch_len < 3) {
             printf("  [MUT] El desvío encontrado es demasiado corto (len=%d). Esto no debería pasar si la lógica de ignorar funciona. Reintentando.\n", patch_len);
             continue;
        }

        printf("  [MUT] ¡Desvío encontrado! Reconstruyendo la ruta...\n");

        int new_path_arcs[nbits[0]];
        int k = 0;
        for (int l = 0; l < i; l++) new_path_arcs[k++] = ind->gene[0][l];
        for (int l = 0; l < patch_len - 1; l++) {
            int arc_idx = find_arc_index(inst, patch_nodes[l], patch_nodes[l+1]);
            if (arc_idx == -1) {
                printf("  [MUT] ERROR CRÍTICO: No se encontró el arco %d -> %d del parche.\n", patch_nodes[l], patch_nodes[l+1]);
                return false;
            }
            new_path_arcs[k++] = arc_idx;
        }
        for (int l = i + 1; l < route_len; l++) new_path_arcs[k++] = ind->gene[0][l];

        rebuild_genes_from_path(ind, new_path_arcs, k, inst->num_arcs);
        
        printf("  [MUT] ¡MUTACIÓN APLICADA CON ÉXITO!\n");
        return true;
    }

    printf("\n  [MUT] Se agotaron los intentos para este individuo. No se pudo mutar.\n");
    return false;
}



// --- FIN DE MUTACIÓN CON DFS ALEATORIZADO ---

// void mutation_ind (individual *ind, Instance *inst)
// {
//     if (randomperc() < pmut_real)
//     {
//         int route_len = ind->sol->length;
//         if (route_len <= 2) return; // No mutation for routes of length 2 or less

//         int i = rnd(1, route_len - 2);
//         int from_node = inst->arcs[ind->sol->arc_used_index[i]].from.id; //completamente criminal
//         int sink_node = inst->arcs[ind->sol->arc_used_index[i+1]].to.id;

//         int current = from_node;
//         //int new_gene[5];
//         int new_index = 0;

//         while (current != sink_node && new_index < 5){

//         }
        
//     }
// }

/* Function to perform mutation of an individual */
// void mutation_ind (individual *ind)
// {
//     if (nreal!=0)
//     {
//         real_mutate_ind(ind);
//     }
//     if (nbin!=0)
//     {
//         bin_mutate_ind(ind);
//     }
//     return;
// }

// /* Routine for binary mutation of an individual */
// void bin_mutate_ind (individual *ind)
// {
//     int j, k;
//     double prob;
//     for (j=0; j<nbin; j++)
//     {
//         for (k=0; k<nbits[j]; k++)
//         {
//             prob = randomperc();
//             if (prob <=pmut_bin)
//             {
//                 if (ind->gene[j][k] == 0)
//                 {
//                     ind->gene[j][k] = 1;
//                 }
//                 else
//                 {
//                     ind->gene[j][k] = 0;
//                 }
//                 nbinmut+=1;
//             }
//         }
//     }
//     return;
// }

// /* Routine for real polynomial mutation of an individual */
// void real_mutate_ind (individual *ind)
// {
//     int j;
//     double rnd, delta1, delta2, mut_pow, deltaq;
//     double y, yl, yu, val, xy;
//     for (j=0; j<nreal; j++)
//     {
//         if (randomperc() <= pmut_real)
//         {
//             y = ind->xreal[j];
//             yl = min_realvar[j];
//             yu = max_realvar[j];
//             delta1 = (y-yl)/(yu-yl);
//             delta2 = (yu-y)/(yu-yl);
//             rnd = randomperc();
//             mut_pow = 1.0/(eta_m+1.0);
//             if (rnd <= 0.5)
//             {
//                 xy = 1.0-delta1;
//                 val = 2.0*rnd+(1.0-2.0*rnd)*(pow(xy,(eta_m+1.0)));
//                 deltaq =  pow(val,mut_pow) - 1.0;
//             }
//             else
//             {
//                 xy = 1.0-delta2;
//                 val = 2.0*(1.0-rnd)+2.0*(rnd-0.5)*(pow(xy,(eta_m+1.0)));
//                 deltaq = 1.0 - (pow(val,mut_pow));
//             }
//             y = y + deltaq*(yu-yl);
//             if (y<yl)
//                 y = yl;
//             if (y>yu)
//                 y = yu;
//             ind->xreal[j] = y;
//             nrealmut+=1;
//         }
//     }
//     return;
// }
