/* Crossover routines */

# include <stdio.h>
# include <stdlib.h>
# include <math.h>
#include <string.h>

# include "global.h"
# include "rand.h"

#define MAX_NODES 5000 
#define MAX_PATCH_LENGTH 10

#define MAX(a, b) ((a) > (b) ? (a) : (b))

/* Function to cross two individuals */
void crossover (individual *parent1, individual *parent2, individual *child1, individual *child2, Instance *instance)
{
    if (nreal!=0)
    {
        realcross (parent1, parent2, child1, child2);
    }
    if (nbin!=0)
    {
        path_based_crossover(parent1, parent2, child1, child2, instance);
    }
    return;
}

/* Routine for real variable SBX crossover */
void realcross (individual *parent1, individual *parent2, individual *child1, individual *child2)
{
    int i;
    double rand;
    double y1, y2, yl, yu;
    double c1, c2;
    double alpha, beta, betaq;
    if (randomperc() <= pcross_real)
    {
        nrealcross++;
        for (i=0; i<nreal; i++)
        {
            if (randomperc()<=0.5 )
            {
                if (fabs(parent1->xreal[i]-parent2->xreal[i]) > EPS)
                {
                    if (parent1->xreal[i] < parent2->xreal[i])
                    {
                        y1 = parent1->xreal[i];
                        y2 = parent2->xreal[i];
                    }
                    else
                    {
                        y1 = parent2->xreal[i];
                        y2 = parent1->xreal[i];
                    }
                    yl = min_realvar[i];
                    yu = max_realvar[i];
                    rand = randomperc();
                    beta = 1.0 + (2.0*(y1-yl)/(y2-y1));
                    alpha = 2.0 - pow(beta,-(eta_c+1.0));
                    if (rand <= (1.0/alpha))
                    {
                        betaq = pow ((rand*alpha),(1.0/(eta_c+1.0)));
                    }
                    else
                    {
                        betaq = pow ((1.0/(2.0 - rand*alpha)),(1.0/(eta_c+1.0)));
                    }
                    c1 = 0.5*((y1+y2)-betaq*(y2-y1));
                    beta = 1.0 + (2.0*(yu-y2)/(y2-y1));
                    alpha = 2.0 - pow(beta,-(eta_c+1.0));
                    if (rand <= (1.0/alpha))
                    {
                        betaq = pow ((rand*alpha),(1.0/(eta_c+1.0)));
                    }
                    else
                    {
                        betaq = pow ((1.0/(2.0 - rand*alpha)),(1.0/(eta_c+1.0)));
                    }
                    c2 = 0.5*((y1+y2)+betaq*(y2-y1));
                    if (c1<yl)
                        c1=yl;
                    if (c2<yl)
                        c2=yl;
                    if (c1>yu)
                        c1=yu;
                    if (c2>yu)
                        c2=yu;
                    if (randomperc()<=0.5)
                    {
                        child1->xreal[i] = c2;
                        child2->xreal[i] = c1;
                    }
                    else
                    {
                        child1->xreal[i] = c1;
                        child2->xreal[i] = c2;
                    }
                }
                else
                {
                    child1->xreal[i] = parent1->xreal[i];
                    child2->xreal[i] = parent2->xreal[i];
                }
            }
            else
            {
                child1->xreal[i] = parent1->xreal[i];
                child2->xreal[i] = parent2->xreal[i];
            }
        }
    }
    else
    {
        for (i=0; i<nreal; i++)
        {
            child1->xreal[i] = parent1->xreal[i];
            child2->xreal[i] = parent2->xreal[i];
        }
    }
    return;
}



// La función `bincross` principal ahora solo delega el trabajo.
// void bincross(individual *parent1, individual *parent2, individual *child1, individual *child2, const Instance *inst) {
//     if (randomperc() <= pcross_bin) {
//         nbincross++;
//         create_hybrid_child(parent1, child1, inst);
//         create_hybrid_child(parent2, child2, inst);
//     } else {
//         memcpy(child1, parent1, sizeof(individual));
//         memcpy(child2, parent2, sizeof(individual));
//     }
// }

// Obtiene la secuencia de NODOS a partir de la secuencia de ARCOS (gene[0])
void get_node_path_from_arcs(Instance *inst, const int* arc_path, int path_len, int* node_path) {
    if (path_len == 0) return;
    // El primer nodo es el 'from' del primer arco
    node_path[0] = inst->arcs[arc_path[0]].from.id;
    // Los nodos siguientes son los 'to' de cada arco
    for (int i = 0; i < path_len; ++i) {
        node_path[i + 1] = inst->arcs[arc_path[i]].to.id;
    }
}

// Reconstruye solo la representación genética del individuo.
// El cálculo de objetivos/restricciones se hace fuera.
void rebuild_genes_from_path(individual *ind, const int* new_arc_path, int path_len, int num_total_arcs) {
    // Limpiar genes
    for (int i = 0; i < path_len; i++) ind->gene[0][i] = new_arc_path[i];
    for (int i = path_len; i < nbits[0]; i++) ind->gene[0][i] = -1; // nbits[0] es la long max del gen

    // Limpiar el gen binario antes de reconstruir
    memset(ind->gene[1], 0, sizeof(int) * num_total_arcs);
    for (int i = 0; i < path_len; i++) {
        ind->gene[1][new_arc_path[i]] = 1;
    }
}


// --- Operador de Cruce Principal ---

// --- Operador de Cruce Principal (Versión Mejorada y Diversificadora) ---

void path_based_crossover(individual *p1, individual *p2, individual *c1, individual *c2, Instance *inst) {
    
    // ¡Ajusta este valor!
    const int num_nodes = 5000; 

    // 1. Obtener longitud de los caminos de los padres
    int p1_len = 0; while (p1_len < nbits[0] && p1->gene[0][p1_len] != -1) p1_len++;
    int p2_len = 0; while (p2_len < nbits[0] && p2->gene[0][p2_len] != -1) p2_len++;

    // Si alguno de los padres es inválido, clonar para seguridad
    if (p1_len == 0 || p2_len == 0) {
        memcpy(c1, p1, sizeof(individual));
        memcpy(c2, p2, sizeof(individual));
        return;
    }

    // 2. Obtener la secuencia de nodos para cada padre
    int p1_nodes[num_nodes];
    int p2_nodes[num_nodes];
    get_node_path_from_arcs(inst, p1->gene[0], p1_len, p1_nodes);
    get_node_path_from_arcs(inst, p2->gene[0], p2_len, p2_nodes);

    // 3. Encontrar nodos comunes
    bool in_p1[num_nodes];
    memset(in_p1, false, sizeof(bool) * num_nodes);
    // Empezamos en i=1 para ignorar el nodo fuente y buscar puntos de cruce más interesantes
    for(int i = 1; i < p1_len; i++) {
        in_p1[p1_nodes[i]] = true;
    }

    int common_nodes[num_nodes];
    int common_count = 0;
    for (int i = 1; i < p2_len; i++) {
        if (in_p1[p2_nodes[i]]) {
            common_nodes[common_count++] = p2_nodes[i];
        }
    }

    // 4. Si no hay nodos comunes, clonar padres. Es la opción segura.
    if (common_count == 0) {
        memcpy(c1, p1, sizeof(individual));
        memcpy(c2, p2, sizeof(individual));
        return;
    }
    
    // 5. Seleccionar un nodo de cruce al azar
    int crossover_node_id = common_nodes[rnd(0, common_count - 1)];

    // 6. Encontrar el índice del arco que LLEGA al nodo de cruce
    int p1_cross_idx = -1, p2_cross_idx = -1;
    for(int i = 0; i < p1_len; i++) if (inst->arcs[p1->gene[0][i]].to.id == crossover_node_id) { p1_cross_idx = i; break; }
    for(int i = 0; i < p2_len; i++) if (inst->arcs[p2->gene[0][i]].to.id == crossover_node_id) { p2_cross_idx = i; break; }
    
    // Si no se encontró el índice (seguridad), clonar.
    if (p1_cross_idx == -1 || p2_cross_idx == -1) {
        memcpy(c1, p1, sizeof(individual));
        memcpy(c2, p2, sizeof(individual));
        return;
    }

    // 7. Construir los nuevos caminos de arcos para los hijos
    int c1_path_arcs[nbits[0]], c2_path_arcs[nbits[0]];
    int c1_len = 0, c2_len = 0;

    for(int i = 0; i <= p1_cross_idx; i++) c1_path_arcs[c1_len++] = p1->gene[0][i];
    for(int i = p2_cross_idx + 1; i < p2_len; i++) c1_path_arcs[c1_len++] = p2->gene[0][i];

    for(int i = 0; i <= p2_cross_idx; i++) c2_path_arcs[c2_len++] = p2->gene[0][i];
    for(int i = p1_cross_idx + 1; i < p1_len; i++) c2_path_arcs[c2_len++] = p1->gene[0][i];

    // 8. Reconstruir los genes de los hijos
    rebuild_genes_from_path(c1, c1_path_arcs, c1_len, inst->num_arcs);
    rebuild_genes_from_path(c2, c2_path_arcs, c2_len, inst->num_arcs);
}