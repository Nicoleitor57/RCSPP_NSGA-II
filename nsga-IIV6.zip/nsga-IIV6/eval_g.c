
#define DEBUG_PRINTS 0
#if DEBUG_PRINTS
#define DPRINT(...) printf(__VA_ARGS__)
#else
#define DPRINT(...)
#endif

# include <stdio.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>


# include "global.h"
# include "rand.h"



void evaluate_objective_g(const Instance *instance, individual *ind) {
    static int seeded = 0;
    if (!seeded) {
        srand((unsigned)time(NULL));
        seeded = 1;
    }
    
    float total_dist = 0.0f;
    float total_time = 0.0f;

    //impririr los arcos usados
    // for (int i = 0; i < instance->num_arcs; i++) {
    //     if (sol->arc_used[i]) {
    //         printf("arco %d: %d -> %d, usado: %d\n", i, instance->arcs[i].from.id, instance->arcs[i].to.id, sol->arc_used[i]);
    //     }
    // }

    //buscar el primer -1 en gene[0], este es el largo de la solución
    int solution_length = 0;
    for (int i = 0; i < instance->num_arcs; i++) {
        if (ind->gene[0][i] == -1) {
            solution_length = i;
            break;
        }
    }

    for (int i = 0; i < solution_length; i++) {
        if (ind->gene[0][i]) {

            float rand_val = (float)rand() / (float)RAND_MAX;
            float risk_sum = (float)instance->arcs[i].from.risk + (float)instance->arcs[i].to.risk;
            float risk_multiplier = 1.0f;
            if (rand_val < risk_sum) {
                risk_multiplier = 1.5f;
            }

            DPRINT("arco %d: %d -> %d, riesgo: %f\n", i, instance->arcs[i].from.id, instance->arcs[i].to.id, risk_sum);
            DPRINT("distancia: %d, tiempo: %d\n", instance->arcs[i].dist, instance->arcs[i].time);
            total_dist += (float)instance->arcs[i].dist + (float)instance->arcs[i].epsilon;
            total_time += ((float)instance->arcs[i].time + (float)instance->arcs[i].epsilon) * risk_multiplier;
            DPRINT("multiplicador de riesgo: %f\n", risk_multiplier);
            DPRINT("distancia: %f, tiempo: %f\n", total_dist, total_time);
        }
    }
    //printf("distancia total: %f, tiempo total: %f\n", total_dist, total_time);

    ind->obj[0] = total_dist;
    ind->obj[1] = total_time;

    //printf("distancia total: %f, tiempo total: %f\n", total_dist, total_time);

}

int check_flow_balance_g(const Instance *instance, const individual *ind) {
    int num_nodes = instance->sink + 1;  // IDs van de 0 a sink
    // Array para llevar cuenta del flujo en cada nodo
    int *flow = calloc(num_nodes, sizeof(int));
    if (!flow) {
        fprintf(stderr, "Error de memoria en check_flow_balance.\n");
        return 0;
    }

    //assert(instance->num_arcs > 0);
    //assert(sol->arc_used != NULL);

    // Recorremos los arcos y verificamos los usados en la solución
    for (int k = 0; k < instance->num_arcs; k++) {
        // printf("Verificando arco %d: %d -> %d, usado: %d\n",
        //        k, instance->arcs[k].from.id, instance->arcs[k].to.id, sol->arc_used[k]);
        if (ind->gene[1][k]) {  // Usamos gene[1] como el vector de arcos usados
            int from_id = instance->arcs[k].from.id;
            int to_id = instance->arcs[k].to.id;

            //assert(from_id >= 0 && from_id < num_nodes);
            //assert(to_id >= 0 && to_id < num_nodes);

            if (from_id < 0 || from_id >= num_nodes || to_id < 0 || to_id >= num_nodes) {
                printf("Error: índice fuera de rango en arco %d: from %d -> to %d\n", k, from_id, to_id);
                exit(1);
            }


            flow[from_id]++;
            flow[to_id]--;
        }
    }

    // Verificación del flujo
    for (int i = 0; i < num_nodes; i++) {
        if (i == instance->source) {
            if (flow[i] != 1) {
                DPRINT("Error de flujo en nodo fuente n%d: esperado +1, obtenido %d\n", i + 1, flow[i]);
                free(flow);
                return 0;
            }
        } else if (i == instance->sink) {
            if (flow[i] != -1) {
                DPRINT("Error de flujo en nodo sumidero n%d: esperado -1, obtenido %d\n", i + 1, flow[i]);
                free(flow);
                return 0;
            }
        } else {
            if (flow[i] != 0) {
                DPRINT("Error de flujo en nodo intermedio n%d: esperado 0, obtenido %d\n", i + 1, flow[i]);
                free(flow);
                return 0;
            }
        }
    }

    free(flow);
    return 1;  // Restricción satisfecha
}

int check_no_subtours_g(const Instance *instance, const individual *ind) {
    int num_nodes = instance->sink + 1;  // +1 porque ID parte en 0
    int *u = calloc(num_nodes, sizeof(int));
    int *visited = calloc(num_nodes, sizeof(int));

    if (!u || !visited) {
        fprintf(stderr, "Error de memoria en check_no_subtours.\n");
        free(u);
        free(visited);
        return 0;
    }

    int current = instance->source;
    u[current] = 0;
    visited[current] = 1;

    int order = 1;

    // Recorremos la solución paso a paso
    while (current != instance->sink) {
        int found = 0;
        for (int k = 0; k < instance->num_arcs; k++) {
            if (ind->gene[1][k] && instance->arcs[k].from.id == current) {
                int next = instance->arcs[k].to.id;

                if (visited[next]) {
                    DPRINT("Ciclo detectado: el nodo n%d ya fue visitado.\n", next + 1);
                    free(u);
                    free(visited);
                    return 0;
                }

                u[next] = order++;
                visited[next] = 1;
                current = next;
                found = 1;
                break;
            }
        }

        if (!found) {
            DPRINT("Ruta inconexa o terminación prematura en nodo n%d.\n", current + 1);
            free(u);
            free(visited);
            return 0;
        }
    }

    // Validar las restricciones MTZ reales
    for (int k = 0; k < instance->num_arcs; k++) {
        if (ind->gene[1][k]) {  // Verificar si el arco está usado
            int i = instance->arcs[k].from.id;
            int j = instance->arcs[k].to.id;

            if (i != instance->source && j != instance->source && i != j) {
                int lhs = u[i] - u[j] + num_nodes;
                int rhs = num_nodes - 1;
                if (lhs > rhs) {
                    DPRINT("Violación MTZ: u[%d] - u[%d] + %d = %d > %d\n",
                           i + 1, j + 1, num_nodes, lhs, rhs);
                    free(u);
                    free(visited);
                    return 0;
                }
            }
        }
    }

    free(u);
    free(visited);
    return 1;
}

int check_resource_limit_g(const Instance *instance, const individual *ind) {
    int total_resource = 0;

    for (int k = 0; k < instance->num_arcs; k++) {
        if (ind->gene[1][k]) {  // Usamos gene[1] como el vector de arcos usados
            total_resource += instance->arcs[k].res;
        }
    }

    if (total_resource > instance->R_max) {
        DPRINT("Violación de límite de recurso: usado %d, máximo permitido %d\n",
               total_resource, instance->R_max);
        return 0;
    }

    return 1;
}

int check_no_forbidden_nodes_g(const Instance *instance, const individual *ind) {
    for (int k = 0; k < instance->num_arcs; k++) {
        if (ind->gene[1][k]) {  // Usamos gene[1] como el vector de arcos usados
            int from = instance->arcs[k].from.id;
            int to = instance->arcs[k].to.id;

            for (int f = 0; f < instance->num_forbidden; f++) {
                int forbidden_node = instance->forbidden[f];
                if (from == forbidden_node || to == forbidden_node) {
                    DPRINT("Arco usado (%d -> %d) pasa por nodo prohibido %d\n",
                           from + 1, to + 1, forbidden_node + 1);
                    return 0;
                }
            }
        }
    }
    return 1;
}

int check_required_nodes_g(const Instance *instance, const  individual *ind) {
    int num_required = instance->num_required;
    int *visited = calloc(instance->sink + 1, sizeof(int));

    if (!visited) {
        fprintf(stderr, "Error de memoria en check_required_nodes.\n");
        return 0;
    }

    // Marcar los nodos que reciben entrada
    for (int k = 0; k < instance->num_arcs; k++) {
        if (ind->gene[1][k]) {  // Usamos gene[1] como el vector de arcos usados
            int to = instance->arcs[k].to.id;
            visited[to] = 1;
        }
    }

    for (int i = 0; i < num_required; i++) {
        int req = instance->required[i];
        if (!visited[req]) {
            DPRINT("Nodo requerido n%d no fue visitado.\n", req + 1);
            free(visited);
            return 0;
        }
    }

    free(visited);
    return 1;
}

int validate_time_windows_g(const individual *ind, const Instance *inst) {
    int num_nodes = inst->sink + 1;
    int violations = 0;

    // Inicializar tiempos de llegada
    // printf("Inicializando tiempos de llegada para %d nodos.\n", num_nodes);
    // for (int i = 0; i < num_nodes; i++) {
    //     arrival_time[i] = 0.0f;
    // }

    int solution_length = 0;
    for (int i = 0; i < inst->num_arcs; i++) {
        if (ind->gene[0][i] == -1) {
            solution_length = i;
            break;
        }
    }

    for (int k = 0; k < solution_length; k++) {
        int arc_used = ind->gene[0][k];
        DPRINT("-------------------------\n");
        DPRINT("arco usado %d\n", arc_used);
        int from = inst->arcs[arc_used].from.id;
        int to = inst->arcs[arc_used].to.id;
        DPRINT("arco %d: %d -> %d, usado: %d\n", k, from + 1 , to + 1, arc_used);

        int to_start = inst->nodes[to].earliest;
        int to_end = inst->nodes[to].latest;
        DPRINT("ventana de tiempo del nodo %d: [%d, %d]\n", to + 1, to_start, to_end);

        float travel_time = inst->arcs[arc_used].time;
        ind->gene[2][to] = ind->gene[2][from] + travel_time;

        if (ind->gene[2][to] < to_start || ind->gene[2][to] > to_end) {
            DPRINT("❌ Violación en nodo %d: llegada %.2f fuera de [%d, %d]\n", to + 1, ind->gene[2][to], to_start, to_end);
            if (!already_recorded(to, ind->gene[3], violations)) {
                ind->gene[3][violations] = to;
                violations++;
            }
        } else {
            DPRINT("✅ Llegada válida a nodo %d: llegada %.2f dentro de [%d, %d]\n", to + 1, ind->gene[2][to], to_start, to_end);
        }
    }

    return violations;
}

bool already_recorded_g(int node, individual *ind, int count) {
    for (int i = 0; i < count; i++) {
        if (ind->gene[3][i] == node) {
            return true;
        }
    }
    return false;
}


